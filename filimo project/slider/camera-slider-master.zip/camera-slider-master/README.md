# camera-slider
Camera slideshow; A jQuery slideshow with many effects, transitions, easy to customize, using canvas and mobile ready, based on jQuery 1.9.1+
Live Demo: https://azhar47.github.io/camera-slider/     
---------------- ||---------------
For More Info(Plugin): https://www.pixedelic.com/plugins/camera 
---------------- ||---------------
For any query: http://azharmasum.com/
